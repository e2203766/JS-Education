let studentname = prompt("Please enter student's name");
let projectwork = confirm("Has the student completed their project work");
let exampoints = prompt("How many points is the exam worth (1-100)");


if (exampoints < 0 || exampoints > 100){
    alert("Number of points in exam is ouside of the range 1-100");
}
else if(!projectwork){
    alert(`Name: ${studentname}\nProject WS: Incomplete\nExam: ${exampoints}\nFinal Grade: 0`);
}
else if(exampoints<40){
    alert(`Name: ${studentname}\nProject WS: Complete\nExam: ${exampoints}\nFinal Grade: 0`);
}
else if(exampoints<50){
    alert(`Name: ${studentname}\nProject WS: Complete\nExam: ${exampoints}\nFinal Grade: 1`);
}
else if(exampoints<60){
    alert(`Name: ${studentname}\nProject WS: Complete\nExam: ${exampoints}\nFinal Grade: 2`);
}
else if(exampoints<70){
    alert(`Name: ${studentname}\nProject WS: Complete\nExam: ${exampoints}\nFinal Grade: 3`);
}
else if(exampoints<85){
    alert(`Name: ${studentname}\nProject WS: Complete\nExam: ${exampoints}\nFinal Grade: 4`);
}
else if(exampoints>=85){
    alert(`Name: ${studentname}\nProject WS: Complete\nExam: ${exampoints}\nFinal Grade: 5`);
}

let Hello = confirm("Kiitos!");