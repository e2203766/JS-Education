let lower_bound = prompt("Please enter the lower bound:");
let upper_bound = prompt("Please enter the upper bound:");


if(lower_bound>upper_bound) {
     let temp = lower_bound;
     lower_bound = upper_bound;
     upper_bound = temp;

}

let even_numbers;
for(let i = lower_bound; i <= upper_bound; i ++) {
    if (i % 2 == 0) {
        even_numbers += `${i}, `;
        if (even_numbers == `undefined${i},`) {
            even_numbers = `${i},`;
            
        }
    }

}

alert(`the even numbers between ${lower_bound} and ${upper_bound} are:\n${even_numbers}`);

