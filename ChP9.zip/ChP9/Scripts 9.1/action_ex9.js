function addData() {
    let num1=0, num2=0;
    num1=document.forms["add_form"].elements["num1"].value;
    num2=document.forms["add_form"].elements["num2"].value;
    let value=parseFloat(num1) + parseFloat(num2);
    document.getElementById("add_res").value=value;
}
function subData() {
    let num3=0, num4=0;
    num3=document.forms["sub_form"].elements["num3"].value;
    num4=document.forms["sub_form"].elements["num4"].value;
    let value=parseFloat(num3) - parseFloat(num4);
    document.getElementById("sub_res").value=value;
}
function multData() {
    let num5=0, num6=0;
    num5=document.forms["mult_form"].elements["num5"].value;
    num6=document.forms["mult_form"].elements["num6"].value;
    let value=parseFloat(num5) * parseFloat(num6);
    document.getElementById("mult_res").value=value;
}
function divData() {
    let num7=0, num8=0;
    num7=document.forms["div_form"].elements["num7"].value;
    num8=document.forms["div_form"].elements["num8"].value;
    let value=parseFloat(num7) / parseFloat(num8);
    document.getElementById("div_res").value=value;
}
function perceData() {
    let num9=0, num10=0;
    num9=document.forms["perce_form"].elements["num9"].value;
    num10=document.forms["perce_form"].elements["num10"].value;
    let value=parseFloat(num9) % parseFloat(num10);
    document.getElementById("perce_res").value=value;
}