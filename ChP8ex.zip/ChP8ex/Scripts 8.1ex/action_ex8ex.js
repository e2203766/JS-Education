function clearData(){
    document.getElementById("summary").innerHTML="";
}

function displayData() {

    const form = document.forms["reg_form"];
    let formData = "<tr>";

    for (let i=0; i <form.length-1 ;i++){
        formData += "<td>" + form.elements[i].value + "</td>";

    }
    if (formData == "") {
        alert("Name must be filled out");
        return false;

    }
    formData+="</tr>";
    document.getElementById("summary").innerHTML+=formData;
    
}
    function checkForm() {
        let errTitle=document.getElementById("errTitle")
        if(document.getElementById("title").value == "") {
            errTitle.textContent="Please fill in";
            errTitle.style.color="red"
        }else {
              errTitle.textContent= "";
            }
            let errLocation=document.getElementById("errLocation")
                   if(document.getElementById("location").value == "") {
            errLocation.textContent="Please fill in";
            errLocation.style.color="red"
        }else {
              errLocation.textContent= "";
            }
            let errDate=document.getElementById("errDate")
        if(document.getElementById("date").value == "") {
            errDate.textContent="Please fill in";
            errDate.style.color="red"
        }else {
              errDate.textContent= "";
            }
            let errpName=document.getElementById("errpName")
        if(document.getElementById("pName").value == "") {
            errpName.textContent="Please fill in";
            errpName.style.color="red"
        }else {
              errpName.textContent= "";
            }

          }
    