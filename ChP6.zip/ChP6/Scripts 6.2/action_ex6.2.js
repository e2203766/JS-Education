
const students=[];
   let student={
     initValues:(id, name, points, project)=>
     {
       this.name=name;
        this.id=id;
          this.points=points;
           this.project=project;
    },
    getGrade:function()
    {
        
    if(!project){return `You have faild the course`;

       } else if (points<40) this.grade=0;
           else if (points<50)  this.grade=1;
             else if (points<60) this.grade=2;
               else if (points<70) this.grade=3;
                 else if (points<85) this.grade=4;
                   else this.grade=5;
        return this.grade;
     },
       //using getinfo function as a method...
  getInfo: function() {return(`Name:${name} \nid ${id} \nExam Points: ${points} \nProject completed: ${project} \nGrade: ${student.getGrade()}`)
}
};
    let checkName=(name)=>{
        return /^[A-Za-z\s]*$/.test(name);
}
    let checkNumbers=(number)=>{
        return/^[0-9]+$/.test(number);
}
    let studentCount;

    do{
        studentCount=prompt("How many students?")
        }while(studentCount<0 || !checkNumbers(studentCount));

        for(let i=0; i<parseInt(studentCount); i++) {
    do{
        studentName=prompt(`Enter student number ${i+1} name`);
        }while(!checkName(studentName));

        let studentId=prompt("Enter you ID");
        let studentProject=confirm("Have you done the cource project work\n if yes please press Ok")
        let studentPoints;

    do{
            studentPoints=prompt("Enter your exam pints");
        }while(studentPoints<0 || studentPoints>=100 ||!checkNumbers(studentPoints))
        studentCopy={
            ...student
            };
        studentCopy.initValues(studentId, studentName, studentPoints, studentProject);
        students.push(studentCopy);
        studentCopy.getGrade();
    alert (studentCopy.getInfo());
}