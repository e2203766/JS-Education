const product ={
    initValues: function(name, price, amount){
        this.name=name;
         this.price=price;
          this.amount=amount;
           //this.currentDate=date;
           
    },
    //arr func
    totalValue:()=> product.price * product.amount,
     checkPrice: (refPrice)=>(product.price<=refPrice) ? "Reasonable" : "Expensive",
      checkDate: (date, exDate)=> (date>exDate) ? "Expired" : "Not Expired",
};
    let productName=prompt("Please, enter product name", "Fish");
     let productPrice=prompt("Please, enter product price", 1.40);
      let productAmount=prompt("Please, enter product amount", 70);
       //let productDate = prompt("Please, enter product date y/m/d like 2022-11-30");
    
    const currentDate = new Date();
     const expiryDate=new Date("2022-11-30 09:30:20");


product.initValues(productName, productPrice, productAmount);
 product.checkDate(currentDate, expiryDate);

     let referencePrice=1.7;

alert(`The price of ${product["name"]} is ${product["price"]}, which is: ${product.checkPrice(referencePrice)}. Its total value is ${product.totalValue()}. the product is ${product.checkDate()}`);