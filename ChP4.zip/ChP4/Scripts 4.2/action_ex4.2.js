//Write a web page in which you use JavaScript and define a function, which receives as argument an array of numbers and a character (like, 'a' or 'd') and then sorts the content of the array either in ascending or descending order and returns the sorted array. Set a default value for the second parameter of the function



function sortArr(arr,letter){
    if(letter==="a"){
        for (let i = 0; i < arr.length; i++){
            for (let j = i + 1; j < arr.length; j++){
            if (arr[i] > arr[j]) {
                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;


            }
        }
    }
}

           else if (letter==="d"){
            for (let i = 0; i < arr.length; i++){
                for (let j = i + 1; j < arr.length; j++){
                if (arr[i] < arr[j]) {
                    temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
    
                }
            }
        }

           }
           
            
           //return arr
           //how to return to the parameter selection again if you mistakenly entered other data,without exiting the menu?
        }
        var arr = [] ;
        for (var i=0; i<5;i++){
            arr[i] = prompt (`Enter array Element` + (i+1));
//sorting is not correct if there is a two-digit number and a one-digit number!(ex:1,3,45,6,7)
        }
        let order = prompt ("How do you wamt to sort? Please choose `a` for ascending or `d` for descending", "a");

         sortArr(arr,order);
         alert(arr);