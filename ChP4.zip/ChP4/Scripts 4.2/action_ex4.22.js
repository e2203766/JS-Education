



function sortArr(arr,letter){
    if(letter==="Babushka"){
        for (let i = 0; i < arr.length; i++){
            for (let j = i + 1; j < arr.length; j++){
            if (arr[i] > arr[j]) {
                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;

            }
        }
    }
}

           else if (letter==="Dedushka"){
            for (let i = 0; i < arr.length; i++){
                for (let j = i + 1; j < arr.length; j++){
                if (arr[i] < arr[j]) {
                    temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
    
                }
            }
        }

           }else{
            return "Please, set the second parameter Babushka or Dedushka"
           }
           while ( !letter) {
            letter = prompt ("Please, set the second parameter Babushka or Dedushka");
        }
           return arr
           
        }

        var arr = [] ;
        for (var i=0; i<5;i++){
            arr[i] = prompt (`Enter array Element` + (i+1));

        }
        let order = prompt ("How do you wamt to sort? Babushka or Dedushka", "Babushka");

        alert (sortArr(arr,order));