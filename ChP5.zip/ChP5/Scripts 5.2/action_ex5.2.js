    //Write a web page in which you use JavaScript to write a program, which asks the users to enter a username and password and depending on whether the username and password are correct or not it calls different callback functions to display a welcome message with current date and time or an error message notifying that the given username and password pair is not correct . The function should receive the correct username and password as well as the callback functions as arguments. 
    
    let userName = prompt(`Please, enter your Name`);
    let password = prompt(`Please, enter your password`);

    //we using arrow functions

    let correct = () => alert(`Welcome, it is` + Date());
    let wrong = ()=> alert(`Your name or/and password is incorrect!`);
        logIn(userName, password, correct, wrong);

    //we using callback function

function logIn(userName, password, correct, incorrect){
    const correctUn = "User 1"; const correctPwd = "1234";
    //let userN = prompt(`Enter your Name`);
   // let passw = prompt(`Enter your password`);
       if(correctUn == userName && correctPwd == password){
        correct();
       }
       else{
        incorrect();
       }
}