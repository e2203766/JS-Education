//Write a web page in which you use JavaScript and define a function, which uses callback functions to sort an array of numbers, which it receives as argument either in ascending or descending order. The function must ask the user, whether the numbers should be sorted in ascending or descending order and then appropriate function to sort the given array of numbers in ascending or descending order.
function toSort (number,actionA,actionB,order="a"){
    
    if (order == `a`) { actionA(number)
    } 
    else if (order == `d`){ actionB(number)
    }
    else
    actionA(Number);
}

function ascendingOrder(number){
    alert("Original array" + number);
    let temp;
    for (let index = 0; index < number.length - 1; index++){
        for (let index_2 = index + 1; index_2 < number.length; index_2++){
            if (parseFloat(number[index]) > parseFloat(number[index_2])){
                temp = number[index];
                number[index] = number[index_2];
                number[index_2] = temp;
            }
        }
    }
    alert(number);
}

function descendingOrder(number){
    let temp;
    alert("Original array" + number);
    for (let index = 0; index < number.length - 1; index++){
        for (let index_2 = index + 1; index_2 < number.length; index_2++){
            if (parseFloat(number[index]) < parseFloat(number[index_2])){
                temp = number[index];
                number[index] = number[index_2];
                number[index_2] = temp;
            }
        }
    }
    alert(number);
}

numbers = [];
let limit=prompt("How many numbers?")
for (let i = 0; i < parseInt(limit); i++){
    let number = Number(prompt(`Enter a number, please`));
    numbers.push(number);
}
let order = prompt ("Choose the order, ascending (a) or descending (d) order");
toSort(numbers,ascendingOrder, descendingOrder, order);