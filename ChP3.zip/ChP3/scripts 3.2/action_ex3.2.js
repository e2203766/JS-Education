// Write a web page in which you use JavaScript and define a function, which prompts for student's course information and calculate the final grade of the student. The function should ask student's name and then ask whether the course project work has been done or no, and then ask the amount of points from the exam (0-100). Otherwise, the function must return a summary of the student's information: name, status of the project work, exam points and final grade according to the following rules:
function Project_results(Name){
let projectdone = confirm(`${Name}, have you done the course project work?(Yes=Ok)`);
let exampoints = prompt(`${Name}, Pleas, write the amount of points from the exam (0-100)`);
let Information = `Name: ${Name}\n status of the project work: Done\n exam points: ${exampoints}\n final grade: `

//if the project work has not been done, the student fails the course. if the project work has been done, then the final course grade will be calculated based on the exam points in the following way:if exam points<40, the final grade will be 0 and so on..
if (!projectdone){
    return(`Name: ${Name}\n status of the project work: not Done\n: ${Name}, you failed the course`);
}
else {
    if(exampoints<40 && exampoints >=0 ){
    return(`${Information} 0`);
}
else if(exampoints<50 && exampoints >=0 ){
    return(`${Information} 1`);
}
else if(exampoints<60 && exampoints >=0 ){
    return(`${Information} 2`);
}
else if(exampoints<70 && exampoints >=0 ){
    return(`${Information} 3`);
}
else if(exampoints<85 && exampoints >=0 ){
    return(`${Information} 4`);
}
else if(exampoints <=100 && exampoints >=0){
    return(`${Information} 5`);
}
else {
    return(`Sorry;given data is not valid`);
}
}
}
let Name = prompt(`Please, enter you name!`);
alert(Project_results(Name));