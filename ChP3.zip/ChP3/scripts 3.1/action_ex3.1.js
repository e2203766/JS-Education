// Write a web page in which you use JavaScript and define a function, which prompts for two integer numbers (lower bound and upper bond) and displays all even numbers between the lower bound and upper bound. The program must still work and display the list of even numbers between two given numbers if the lower bound is greater than the upper bound.
function even_numbers_in_between(LoverBound, UpperBound){
let Numbers = [          ];

if (LoverBound < UpperBound){
for( let Number = LoverBound + 1; Number < UpperBound;Number++){
if(Number % 2 == 0){
        Numbers.push(Number);
     }
   };
}
else {
    for( let Number = UpperBound + 1; Number < LoverBound;Number++){
        if(Number % 2 == 0){
            Numbers.push(Number);
      }
   }
}
//terminates the current function and returns it
return Numbers;
}
let LoverBound= Number(prompt("Please, enter the lover bound!"));
let UpperBound= Number(prompt("Please, enter the upper bound!"));

alert(`Even numbers betveen ${LoverBound} and ${UpperBound} are: ${even_numbers_in_between(LoverBound, UpperBound)}`);