let appointmentJSON=`{"appointmentsArr":[`+
` {"title": "Programming", "location": "VamkUniversity", "duration": "1:30min", "date":"09.12.2022", "time":"1pm", `+
`"participants":[`+
`{"firstName":"Kostya", "lastName": "Chygrin", "phoneNumber": "0507777771", "participation": "true"},`+
`{"firstName":"Sarah", "lastName": "Conar", "phoneNumber": "0507777772", "participation": "true"},`+
`{"firstName":"Jack", "lastName": "Daniels", "phoneNumber": "0507777773", "participation": "false"}]},`+

` {"title": "Vaasa", "location": "RailwayStation", "duration": "50min", "date":"06.01.2023", "time":"10am",` +
`"participants":[`+
`{"firstName":"Volodimir", "lastName": "Zelenskiy", "phoneNumber": "0507777771", "participation": "true"},`+
`{"firstName":"Arnold", "lastName": "Schwarzenegger", "phoneNumber": "0507777772", "participation": "true"},`+
`{"firstName":"John", "lastName": "Vu", "phoneNumber": "0507777773", "participation": "false"}]},`+

` {"title": "Club", "location": "Monaco", "duration": "4ours", "date":"09.11.2023", "time":"22pm", `+
`"participants":[`+
`{"firstName":"Angelina", "lastName": "Joli", "phoneNumber": "0507777771", "participation": "true"},`+
`{"firstName":"Billy", "lastName": "Ailish", "phoneNumber": "0507777772", "participation": "false"},`+
`{"firstName":"Natali", "lastName": "simple Natali", "phoneNumber": "0507777773", "participation": "true"}]}`+ 
`]}`;



let appointment= JSON.parse(appointmentJSON);
let info=prompt("Enter the name of the property", "Location");
let data="The list of the requested property:\n";


switch (info){

    case "Title":
    case "title":
    for(let i=0; i<appointment.appointmentsArr.length; i++)
    data+= `\nTitle ${i+1}:`+ appointment.appointmentsArr[i].title
    break;

    case "Location":
      case "location":
    for(let i=0; i<appointment.appointmentsArr.length; i++)
    data+= ` \nLocation ${i+1}: `+ appointment.appointmentsArr[i].location
    break;

    case "Duration":
    case "duration":
    for(let i=0; i<appointment.appointmentsArr.length; i++)
    data+= `\nDuration ${i+1}:`+ appointment.appointmentsArr[i].duration
    break;

    case "Date":
    case "date":
    for(let i=0; i<appointment.appointmentsArr.length; i++)
    data+= `\nDate ${i+1}:`+ appointment.appointmentsArr[i].date
    break;

    case "Time":
    case "time":
    for(let i=0; i<appointment.appointmentsArr.length; i++)
    data+= `\nTime ${i+1}:`+ appointment.appointmentsArr[i].time
    break;

    case "Participants":
    case "participants":
    for(let i=0; i<appointment.appointmentsArr.length; i++)
    for(let j=0; j<appointment.appointmentsArr[i].participants.length; j++)
    data+= `\n`+ appointment.appointmentsArr[i].participants[j].firstName +`\n`+ appointment.appointmentsArr[i].participants[j].lastName
    break;

    default:
      data="Please enter the required property correctly";

}

alert (data);
//https://js.cx/clipart/train.gif