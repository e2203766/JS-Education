let appointment =  ` {"appointment" : {"title": "Programming", "location": "Vamk University", "duration": "12:50 min", "date":"09.12.2022", "time":"12:30", "participants":[{"firstname":"Kostya", "lastname": "Chygrin", "phoneNumber": "0507777771", "participation": true},{"firstname":"Henry", "lastname": "Troy", "phoneNumber": "0507777772", "participation": true},{"firstname":"Barnaby", "lastname": "Vu", "phoneNumber": "0507777773", "participation": false}]}}`;

let appointmentObj=JSON.parse(appointment);
alert("Title: " +  
appointmentObj.appointment.title +
"\nLocation:" + appointmentObj.appointment.location+ 
"\nDuration: " + appointmentObj.appointment.duration+ "\nDate:" + 
appointmentObj.appointment.date+ "\nTime:"+appointmentObj.appointment.time+ 
"\nParticipants:\n" +appointmentObj.appointment.participants[0].firstname+ "" +
appointmentObj.appointment.participants[0].lastname+ "\n" +appointmentObj.appointment.participants[1].firstname+ "" +
appointmentObj.appointment.participants[1].lastname+ "\n" + appointmentObj.appointment.participants[2].firstname+ "" +
appointmentObj.appointment.participants[2].lastname);
