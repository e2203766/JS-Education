let appointmentJSON=` {"title": "Programming", "location": "Vamk", "duration": "45min", "date":"20.11.2022", "time":"10am", "participants":[`+
`{"firstname":"firstname1", "lastname": "lastname1", "phoneNumber": "0507777771", "participation": "true"},`+
`{"firstname":"firstname2", "lastname": "lastname2", "phoneNumber": "0507777772", "participation": "true"},`+
`{"firstname":"firstname3", "lastname": "lastname3", "phoneNumber": "0507777773", "participation": "false"}]}`

let appointment=JSON.parse(appointmentJSON);

const result="Appointment: " + appointment.title + "Location:" + appointment.location+ "\nDuration: " + appointment.duration+ "Date:" + appointment.date+ "Time:"+appointment.time+ "\n\nParticipants:" +appointment.participants+
"\n" + appointment.participants[0].firstName+ "" +appointment.participants[0].lastName+ ""+appointment.participants[0].phoneNumber+ ""+appointment.participants[0].participation+
"\n" + appointment.participants[1].firstName+ "" +appointment.participants[1].lastName+ ""+appointment.participants[1].phoneNumber+ ""+appointment.participants[1].participation+
"\n" + appointment.participants[2].firstName+ "" +appointment.participants[2].lastName+ ""+appointment.participants[2].phoneNumber+ ""+appointment.participants[2].participation;

alert(result);
//const result=